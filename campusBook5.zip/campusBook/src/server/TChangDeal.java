package server;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mybean.CheckTime;
import com.mybean.ConnectMydb;

public class TChangDeal extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session=request.getSession();
		String stime="",addr="";
		int mark=0,flag=0,timelen=0,pNum=0;
		int pid=(Integer)session.getAttribute("pid");
		String tname=(String)session.getAttribute("Tname");
		String pushtime=(String)session.getAttribute("pushtime");
		Connection conn=null;
		ConnectMydb Condb=new ConnectMydb();
		CheckTime Checkt=new CheckTime();	
		conn=Condb.Conmydb();
		if(request.getParameter("stime")!=""){
			stime=request.getParameter("stime");
		if(!Checkt.islegalform(stime)){
			flag=1;		
		}
		else{	
		if(!Checkt.islegaldate(stime)){
			mark=1;
			session.setAttribute("mark",mark);
		   response.sendRedirect("http://localhost:8080/campusBook/tChangResult.jsp");
			return ;
		 }
		if(!Checkt.CompareNow(stime)){
			mark=2;
			session.setAttribute("mark",mark);
			response.sendRedirect("http://localhost:8080/campusBook/tChangResult.jsp");
		    return ;
		}
		}
		}
		try{
			if(request.getParameter("stime")!=""){
			  stime=request.getParameter("stime");
			if(flag==0){
		      String sql="select * from tpushtb where tname='"+tname+"'";
		      PreparedStatement ps=conn.prepareStatement(sql);
		      ResultSet rs=ps.executeQuery();
		      while(rs.next())
		      {
			   if(rs.getInt("flag")==0&&rs.getInt("pushID")!=pid&&Checkt.istimeconflict(stime,timelen,rs.getString("stime"),rs.getInt("timelen"))&&rs.getString("tag").equals("正常")){
				   mark=3;
				   session.setAttribute("mark",mark);
				   System.out.print("3");
				   ps.close();
			       rs.close();
			       conn.close();
			       response.sendRedirect("http://localhost:8080/campusBook/tChangResult.jsp");
                   return;
			   }			   
		       }
		      ps.close();
		      rs.close();
			 }
			if(flag==1){
			      String sql="select * from tpushtb where tname='"+tname+"'";
			      PreparedStatement ps=conn.prepareStatement(sql);
			      ResultSet rs=ps.executeQuery();
			      while(rs.next())
			      {
				   if(rs.getInt("flag")==1&&rs.getInt("pushID")!=pid&&stime.equals(rs.getString("stime"))&&pushtime.equals(rs.getString("pushtime"))&&rs.getString("tag").equals("正常")){
					   mark=3;
					   session.setAttribute("mark",mark);
					   System.out.print("3");
					   ps.close();
				       rs.close();
				       conn.close();
				       response.sendRedirect("http://localhost:8080/campusBook/tChangResult.jsp");
	                   return;
				   }			   
			       }
			      ps.close();
			      rs.close();
				 }
			   String sql1="update tpushtb set stime='"+stime+"' ,flag='"+flag+"'where pushID='"+pid+"'";
		       PreparedStatement ps1=conn.prepareStatement(sql1); 
		       int row=ps1.executeUpdate();
               if(row>0){
                mark=4;
               }
               ps1.close();	
			}
			if(request.getParameter("timelen")!=""){
				 timelen=Integer.parseInt(request.getParameter("timelen"));
				 String sql1="update tpushtb set timelen='"+timelen+"'where pushID='"+pid+"'";
			       PreparedStatement ps=conn.prepareStatement(sql1); 
			       int row=ps.executeUpdate();
	               if(row>0){
	                mark=4;
	               }
	               ps.close();	
			}
			if(request.getParameter("addr")!=""){
				 addr=request.getParameter("addr");
				 String sql1="update tpushtb set addr='"+addr+"'where pushID='"+pid+"'";
			       PreparedStatement ps=conn.prepareStatement(sql1); 
			       int row=ps.executeUpdate();
	               if(row>0){
	                mark=4;
	               }
	               ps.close();	
			}
			if(request.getParameter("personNum")!=""){
				 pNum=Integer.parseInt(request.getParameter("personNum"));
				 String sql1="update tpushtb set pNum='"+pNum+"'where pushID='"+pid+"'";
			     PreparedStatement ps=conn.prepareStatement(sql1); 
			     int row=ps.executeUpdate();
	             if(row>0){
	              mark=4;   		     
	              }
	               ps.close();	
			}
			 session.setAttribute("mark",mark);
		       conn.close();
		       response.sendRedirect("http://localhost:8080/campusBook/tChangResult.jsp");
		       return;
		}catch(Exception e){ 
        	e.printStackTrace();
        	}		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        doGet(request,response);
	}

}
