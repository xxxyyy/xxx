package server;

import com.mybean.PushTime;
import com.mybean.ConnectMydb;

import java.awt.List;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.ArrayList;
import java.util.Date;
import java.text.*;
import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.PreparedStatement;
import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.sql.Statement; 

public class TChangPush extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		int pid=Integer.parseInt(request.getParameter("Id"));
		Connection conn=null;
		ConnectMydb Condb=new ConnectMydb();
		ArrayList <PushTime> ptlist=new ArrayList<PushTime>();
		HttpSession session=request.getSession();
		conn=Condb.Conmydb();
		try{
	      String sql="select * from tpushtb where pushID='"+pid+"'";
	      PreparedStatement ps=conn.prepareStatement(sql);
	      ResultSet rs=ps.executeQuery();
	      while(rs.next())
	      {
	    	  PushTime ptmp=new PushTime();
	    	  ptmp.setPushID(rs.getInt("pushID"));
	    	  ptmp.setTname(rs.getString("tname"));
	    	  ptmp.setStime(rs.getString("stime"));
	    	  ptmp.setTimelen(rs.getInt("timelen"));
	    	  ptmp.setAddr(rs.getString("addr"));
	    	  ptmp.setPNum(rs.getInt("pNum"));
	    	  ptmp.setPushtime(rs.getString("pushtime"));
	    	  ptmp.setBookPNum(rs.getInt("bookPNum"));
	    	  ptmp.setStatus(rs.getString("status"));
	    	  ptmp.setTag(rs.getString("tag"));
	    	  ptmp.setFlag(rs.getInt("flag"));
	    	  ptlist.add(ptmp);
	    	  session.setAttribute("pid",rs.getInt("pushID"));
	    	  session.setAttribute("pushtime",rs.getString("pushtime"));
	      }
	      session.setAttribute("ptlist",ptlist);
	      ps.close();
	      rs.close();
	      conn.close();
	      response.sendRedirect("http://localhost:8080/campusBook/tChang.jsp");
		}catch(Exception e){ 
        	e.printStackTrace();
        	}	
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		  doGet(request,response);
	}

}
