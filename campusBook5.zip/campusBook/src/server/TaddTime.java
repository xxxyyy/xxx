package server;

import com.mybean.CheckTime;
import com.mybean.ConnectMydb;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.ArrayList;
import java.util.Date;
import java.text.*;
import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.PreparedStatement;
import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.sql.Statement; 

public class TaddTime extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session=request.getSession();
		HttpSession ses=request.getSession();
	   	String tname=(String)session.getAttribute("Tname");
		String stime=request.getParameter("time");
		String tsMode=request.getParameter("tSelectMode");
		String tlen=request.getParameter("timelen");
		String addr=request.getParameter("addr");
		int pNum=Integer.parseInt(request.getParameter("personNum"));
		Date now=new Date();
		DateFormat d1 = DateFormat.getDateInstance(); 
		String pushtime= d1.format(now);
		int mark=0,flag=0,timelen=0;
		Connection conn=null;
		ConnectMydb Condb=new ConnectMydb();
		CheckTime Checkt=new CheckTime();	
		conn=Condb.Conmydb();
		if(!Checkt.islegalform(stime)){
			flag=1;		
		}
		else{	
		if(!Checkt.islegaldate(stime)){
			mark=1;
			ses.setAttribute("mark",mark);
			System.out.print("1");
		   response.sendRedirect("http://localhost:8080/campusBook/tpushDeal.jsp");
			return ;
		 }
		if(!Checkt.CompareNow(stime)){
			mark=2;
			ses.setAttribute("mark",mark);
			System.out.print("2");
			response.sendRedirect("http://localhost:8080/campusBook/tpushDeal.jsp");
		    return ;
		}
		}
		if(tsMode.equals("default")){
			try{
			 String sql="select timelen from tdeftimetb where tname='"+tname+"'";
		     PreparedStatement ps=conn.prepareStatement(sql);
		     ResultSet rs=ps.executeQuery();
		     if(rs.next()){
		    	 timelen=rs.getInt("timelen");
		     }
		     ps.close();
		     rs.close();
			}catch(Exception e){ 
	        	e.printStackTrace();
	        }		
		}
		else{
			timelen=Integer.parseInt(tlen);
		}
		  // ArrayList<TpushtInfo> list=new ArrayList<TpushtInfo>();
		try{
			if(flag==0){
		      String sql="select * from tpushtb where tname='"+tname+"'";
		      PreparedStatement ps=conn.prepareStatement(sql);
		      ResultSet rs=ps.executeQuery();
		      while(rs.next())
		      {
			   if(rs.getInt("flag")==0&&Checkt.istimeconflict(stime,timelen,rs.getString("stime"),rs.getInt("timelen"))&&rs.getString("tag").equals("正常")){
				   mark=3;
				   ses.setAttribute("mark",mark);
				   System.out.print("3");
				   ps.close();
			       rs.close();
			       conn.close();
			       response.sendRedirect("http://localhost:8080/campusBook/tpushDeal.jsp");
                   return;
			   }			   
		       }
		      ps.close();
		      rs.close();
			 }
			if(flag==1){
			      String sql="select * from tpushtb where tname='"+tname+"'";
			      PreparedStatement ps=conn.prepareStatement(sql);
			      ResultSet rs=ps.executeQuery();
			      while(rs.next())
			      {
				   if(rs.getInt("flag")==1&&stime.equals(rs.getString("stime"))&&pushtime.equals(rs.getString("pushtime"))&&rs.getString("tag").equals("正常")){
					   mark=3;
					   ses.setAttribute("mark",mark);
					   System.out.print("3");
					   ps.close();
				       rs.close();
				       conn.close();
				       response.sendRedirect("http://localhost:8080/campusBook/tpushDeal.jsp");
	                   return;
				   }			   
			       }
			      ps.close();
			      rs.close();
				 }
		        String sql1="insert into tpushtb(tname,stime,timelen,addr,pNum,pushtime,flag) values(?,?,?,?,?,?,?)";
		        PreparedStatement ps1=conn.prepareStatement(sql1);
		        ps1.setString(1,tname);
		        ps1.setString(2,stime);
		        ps1.setInt(3,timelen);
		        ps1.setString(4,addr);
		        ps1.setInt(5,pNum);
		        ps1.setString(6,pushtime);
		        ps1.setInt(7,flag);
		        int row=ps1.executeUpdate();
		        if(row>0){
		        mark=4;
		        ses.setAttribute("mark",mark);
		        System.out.print("4");
		        }		       
		        ps1.close();
		        conn.close();
		       response.sendRedirect("http://localhost:8080/campusBook/tpushDeal.jsp");
		       return;
		}catch(Exception e){ 
        	e.printStackTrace();
        	}	
		  // response.sendRedirect("http://localhost:8080/campusBook/tpushDeal.jsp");
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 doGet(request,response);
	}
}
