package server;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mybean.CheckTime;
import com.mybean.ConnectMydb;
import com.mybean.PushTime;

public class TSearchSecPush extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session=request.getSession();
	   	String tname=(String)session.getAttribute("Tname");
		String StimeMode=request.getParameter("StimeMode");
		String TimelenMode=request.getParameter("TimelenMode");
		Date now=new Date();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm");
		String nowtime= df.format(now);
		String stime="";
		int mark=0,timelen=0;
		ArrayList <PushTime> list=new ArrayList<PushTime>();
		Connection conn=null;
		ConnectMydb Condb=new ConnectMydb();
		CheckTime Checkt=new CheckTime();	
		conn=Condb.Conmydb();
	    if(StimeMode.equals("custom")){
		   if(Checkt.islegalform(request.getParameter("stime"))){
				stime=request.getParameter("stime");	
			}
		   else if(Checkt.islegaldateform(request.getParameter("stime"))){
				stime=request.getParameter("stime")+" "+"0:00";	
			}
		   else{
			   mark=1;
			   session.setAttribute("mark",mark);
			   response.sendRedirect("http://localhost:8080/campusBook/tSearchSecResult.jsp");
			   return ;
		   }		   
		}
		else{
			stime=nowtime;
		}
		if(TimelenMode.equals("custom")){
		 timelen=Integer.parseInt(request.getParameter("timelen"));	
		}
		else{
			timelen=7;
		}
		try{
		      String sql="select * from tpushtb where tname='"+tname+"'";
		      PreparedStatement ps=conn.prepareStatement(sql);
		      ResultSet rs=ps.executeQuery();
		      while(rs.next())
		      {
		    	  if(rs.getInt("flag")==0&&Checkt.istimein(stime,timelen,rs.getString("stime"))){
		    	  PushTime ptmp=new PushTime();
		    	  ptmp.setPushID(rs.getInt("pushID"));
		    	  ptmp.setTname(rs.getString("tname"));
		    	  ptmp.setStime(rs.getString("stime"));
		    	  ptmp.setTimelen(rs.getInt("timelen"));
		    	  ptmp.setAddr(rs.getString("addr"));
		    	  ptmp.setPNum(rs.getInt("pNum"));
		    	  ptmp.setPushtime(rs.getString("pushtime"));
		    	  ptmp.setBookPNum(rs.getInt("bookPNum"));
		    	  ptmp.setStatus(rs.getString("status"));
		    	  ptmp.setTag(rs.getString("tag"));
		    	  ptmp.setFlag(rs.getInt("flag"));
		    	  list.add(ptmp);
		    	  }
		      }
		      session.setAttribute("list",list);
		      session.setAttribute("mark",mark);
		      ps.close();
		      rs.close();
		      conn.close();
		      response.sendRedirect("http://localhost:8080/campusBook/tSearchSecResult.jsp");
		      return;
			}catch(Exception e){ 
	        	e.printStackTrace();
	       }	
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
           doGet(request,response);
	}
}
