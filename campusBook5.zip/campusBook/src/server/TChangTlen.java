package server;

import com.mybean.ConnectMydb;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.ArrayList;
import java.util.Date;
import java.text.*;
import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.PreparedStatement;
import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.sql.Statement; 

public class TChangTlen extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session=request.getSession();
		String tname=(String)session.getAttribute("Tname");
		int timelen=Integer.parseInt(request.getParameter("tlen1"));
		int changtlenflag=0;
		Connection conn=null;
		ConnectMydb Condb=new ConnectMydb();
		conn=Condb.Conmydb();
		try{
			 String sql="update tdeftimetb set timelen='"+timelen+"'where tname='"+tname+"'";
		     PreparedStatement ps=conn.prepareStatement(sql); 
		     int row=ps.executeUpdate();
             if(row>0){
            	 changtlenflag=1;        
             }
             session.setAttribute("changtlenflag",changtlenflag);	
             ps.close();
             conn.close();
             response.sendRedirect("http://localhost:8080/campusBook/tChangTlenResult.jsp");
             return;
		}catch(Exception e){ 
        	e.printStackTrace();
        	}		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
      }
}
