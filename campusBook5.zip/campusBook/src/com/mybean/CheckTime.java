package com.mybean;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckTime {
	public static final int[] DAYS_OF_MONTH = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	Date now=new Date();
	DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm");
	public boolean CompareNow(String date1)
	{
	 try{
		 Date dt1 = df.parse(date1);
		 if (dt1.getTime() >= now.getTime()) 
            return true;
		 else
		    return false;		
		}catch (Exception exception) {
            exception.printStackTrace();
	    }
		return false;
	}	
	public boolean CompareStartdate(String date1,String date2)  //比较起终时间
	{
	 try{
		 Date dt1 = df.parse(date1);
		 Date dt2=df.parse(date2);
		 if (dt1.getTime() < dt2.getTime()) 
            return true;
		 else
		    return false;		
		}catch (Exception exception) {
            exception.printStackTrace();
	    }
		return false;
	}
	 public  boolean islegalmonth(int month)
	 {
		 return month>=1&&month<=12;
	 }
	 public boolean islegalday(int year, int month, int day) {
		  if(month == 2 && isLeapYear(year)) {//闰年且是2月份
		   return day >= 1 && day <= 29;
		  }
		  return day >= 1 && day <= DAYS_OF_MONTH[month - 1];//其他月份
		 }
		 
	 public  boolean isLeapYear(int year) {
		  return year % 4 == 0 && year % 100 != 0 || year % 400 == 0;
		 }
	  public  boolean islegalhour(int hour)
	  {
		 return hour>=0&&hour<=23;
	  }	
	 public  boolean islegalminute(int minute)
		 {
			 return minute>=0&&minute<=59;
		 }
	 public boolean islegaldate(String date) {
		 date=date.trim();
		 int year=0,month=0,day=0,hour=0,minute=0;
		 year = Integer.parseInt(date.substring(0,date.indexOf('-')));
		 date = date.substring(date.indexOf('-')+1);
		 month = Integer.parseInt(date.substring(0,date.indexOf('-')));
		 date = date.substring(date.indexOf('-')+1);
		 day = Integer.parseInt(date.substring(0,date.indexOf(' ')));
		 date = date.substring(date.indexOf(' ')+1);
		 hour = Integer.parseInt(date.substring(0,date.indexOf(':')));
		 date = date.substring(date.indexOf(':')+1);
		 minute = Integer.parseInt(date);
		 if(!islegalmonth(month)) { return false; }
		 if(!islegalday(year,month,day)) { return false; }
         if(!islegalhour(hour)) { return false; }
		 if(!islegalminute(minute)) { return false; }
		 return true;
		 }
	 public boolean islegalform(String date)
	 {
		 Pattern p = Pattern.compile("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{1,2}$");
		 Matcher match = p.matcher(date.trim()); 
		 if(match.matches()){ return true;}
		 return false;
	 }
	 public boolean istimeconflict(String date1,int tlen1,String date2,int tlen2)
	 {
	 try{
		 Date dt1 = df.parse(date1.trim());
		 Date dt2 = df.parse(date2.trim());
		 if (dt1.getTime()<=(dt2.getTime()+tlen2*60*1000)&&dt1.getTime()>=dt2.getTime()) 
	            return true;
		 else if((dt1.getTime()+tlen1*60*1000)<=(dt2.getTime()+tlen2*60*1000)&&(dt1.getTime()+tlen1*60*1000)>=dt2.getTime())
			    return true;	
		 return false;
		}catch (Exception exception) {
	            exception.printStackTrace();
		 }
		return false;
	 }
	 public boolean islegaldateform(String date)
	 {
		 Pattern p = Pattern.compile("^\\d{4}-\\d{1,2}-\\d{1,2}$");
		 Matcher match = p.matcher(date.trim()); 
		 if(match.matches()){ return true;}
		 return false;
	 }
	 public boolean istimein(String date1,int tlen1,String date2)
	 {
	 try{
		 Date dt1 = df.parse(date1.trim());
		 Date dt2 = df.parse(date2.trim());
		 if ((dt1.getTime()+tlen1*24*60*60*1000)>=dt2.getTime()&&dt1.getTime()<=dt2.getTime()) 
	            return true;
		 return false;
		}catch (Exception exception) {
	            exception.printStackTrace();
		}
		return false;
	 }	 
}


