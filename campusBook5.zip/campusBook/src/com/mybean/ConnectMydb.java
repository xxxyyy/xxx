package com.mybean;

import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.SQLException;  
public class ConnectMydb {
 public Connection Conmydb()	
 {
     Connection conn=null;
     try{
          Class.forName("com.mysql.jdbc.Driver");
		  String url="jdbc:mysql://localhost:3306/mydb";
		  String username="root";
		  String password="1314";
		  conn=DriverManager.getConnection(url,username,password);
		  return conn;
    }catch(ClassNotFoundException e1){
  		 e1.printStackTrace(); 
    }catch(java.sql.SQLException e){ 
    	System.out.println(e.toString());
    }
     return null;
  }
}
