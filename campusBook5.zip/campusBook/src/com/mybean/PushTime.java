package com.mybean;

public class PushTime {
	private int pushID;
	private String tname;
	private String stime;
	private int timelen;
	private String addr;
	private int PNum;
	private String pushtime;
	private int bookPNum;
	private String status;
    private String tag;
    private int flag;
	public int getPushID() {
		return pushID;
	}
	public void setPushID(int pushID) {
		this.pushID = pushID;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getStime() {
		return stime;
	}
	public void setStime(String stime) {
		this.stime = stime;
	}
	public int getTimelen() {
		return timelen;
	}
	public void setTimelen(int timelen) {
		this.timelen = timelen;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public int getPNum() {
		return PNum;
	}
	public void setPNum(int pNum) {
		PNum = pNum;
	}
	public String getPushtime() {
		return pushtime;
	}
	public void setPushtime(String pushtime) {
		this.pushtime = pushtime;
	}
	public int getBookPNum() {
		return bookPNum;
	}
	public void setBookPNum(int bookPNum) {
		this.bookPNum = bookPNum;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	
}
