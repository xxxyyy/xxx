package com.mybean;

public class TeacherEnter {
	private String tName;
	private String pwd;
	public String getTeaName() {
		return tName;
	}
	public void setTeaName(String username) {
		this.tName = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String password) {
		this.pwd = password;
	}
	
	}
