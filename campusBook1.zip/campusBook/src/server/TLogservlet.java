package server;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.ResultSet;   
import java.sql.Statement; 
public class TLogservlet extends HttpServlet {
	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String tname=request.getParameter("teaname");
		String pwd=request.getParameter("pwd");
	    if(this.check(tname, pwd)){	    	
	    	 response.sendRedirect("http://localhost:8080/campusBook/tlogpass.jsp");
	    	return;
	    }
	    response.sendRedirect("http://localhost:8080/campusBook/LogError.jsp");
      return;
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
             doGet(request,response);
	}
	public boolean check(String tname,String pwd){		
		   Connection conn=null;
		     try{
		          Class.forName("com.mysql.jdbc.Driver");
				  String url="jdbc:mysql://localhost:3306/mydb";
				  String username="root";
				  String password="1314";
				  conn=DriverManager.getConnection(url,username,password);
		 	      Statement stmt=conn.createStatement();
        	String sql="select * from tlogtb";
        	ResultSet rs=stmt.executeQuery(sql);
        	while(rs.next()){
        		if(tname.equals(rs.getString("tname"))&&pwd.equals(rs.getString("pwd"))){
        				return true;			
        		}
        	}
              rs.close();
              stmt.close();
              conn.close();       	
        }catch(ClassNotFoundException e1){ 		
   		 e1.printStackTrace();
        }catch(java.sql.SQLException e){ 
         System.out.println(e.toString());
        }
        return false;
	}
}
	

